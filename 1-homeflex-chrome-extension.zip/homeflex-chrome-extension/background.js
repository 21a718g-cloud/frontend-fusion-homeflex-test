'use strict';
const HOME='https://21a718g-cloud.github.io/frontend-fusion-homeflex-test/';
function capture(tab,labels=[]){
  const u=new URL(tab.url||'');
  if(u.protocol!=='https:'||u.username||u.password||u.port||u.hash||!(u.hostname==='photos.google.com'&&/^\/(?:u\/\d+\/)?(?:album|share)\/[A-Za-z0-9_-]+(?:\/photo\/[A-Za-z0-9_-]+)?\/?$/.test(u.pathname)))throw new Error('Open the Google Photos shared album first.');
  u.pathname=u.pathname.replace(/\/photo\/[^/]+$/, '');
  const title=(tab.title||'').replace(/ - Google Photos$/,'').trim();
  if(!title||title==='Google Photos'||title.length>120||/[\u0000-\u001f\u007f]/.test(title))throw new Error('Wait for the album title to load, then click again.');
  return HOME+'#capture='+encodeURIComponent(JSON.stringify({title,url:u.href,labels}));
}
chrome.action.onClicked.addListener(async tab=>{
  try{
    capture(tab); // Validate origin/path before reading visible labels.
    const result=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>{
      const text=document.querySelector('main')?.innerText||'';
      return [...new Set(text.split(/\r?\n/).map(x=>x.trim()).filter(x=>/^.+? \| S\d{2}E\d{2} - .+$/.test(x)||/^.+? S\d{2}E\d{2}(?:\.(?:mp4|mkv|avi|mov))?$/i.test(x)))].slice(0,100);
    }});
    await chrome.tabs.create({url:capture(tab,result[0]?.result||[])});await chrome.action.setBadgeText({text:''});await chrome.action.setTitle({title:'Save album to HomeFlex as Draft'});}
  catch(err){await chrome.action.setBadgeText({text:'!'});await chrome.action.setBadgeBackgroundColor({color:'#9b2838'});await chrome.action.setTitle({title:err.message});}
});
