# HomeFlex local album capture (test version)
1. Download homeflex-chrome-extension.zip from this test site/repo and unzip it.
2. In desktop Chrome open chrome://extensions, turn on Developer mode, choose Load unpacked, select the unzipped folder containing manifest.json.
3. Pin HomeFlex local album capture in the Chrome Extensions menu.
4. Open a Google Photos shared album normally. Wait for its real title, then click the extension once.
5. A new test HomeFlex tab receives the title and full shared URL, stores an Album/Collection Draft and removes the fragment payload from the address. No episode number is guessed. Review it in the same Chrome profile. It never auto-publishes.

Only activeTab and scripting permissions, no all-sites access, clipboard, OAuth, remote calls or media downloads. The extension reads the browser's already-loaded tab title and URL, not media contents; reads visible episode labels on click. Normal Google navigation requires internet and whatever sharing access Google requires. Capture handoff stays in a URL fragment, never a server query. Browser history/extension/page context can still see the URL while transferring; anyone with the album link may have access according to Google sharing settings. Export backups, clearing site data deletes this local library. Chrome Incognito or another profile has separate storage.

The extension target is the separate public Fusion+HomeFlex test origin only. Its public code contains no actual album links. This is not a Google product or approved Google API integration.

Episode preview: open an episode's Info panel, then click the extension. Visible description/filename labels `Series S01E01` or `Series S01E01.mp4` become a preview with original label as title, no invented subtitles. Review then Apply Drafts. This only sees loaded visible labels; no automatic traversal, scrolling or completeness claim. On album page without visible labels it captures the collection title. Google layout changes may break extraction.

Exact episode link: open one episode and its Info panel, then click the extension. Captures that item's /share/.../photo/... URL together with its filename/description into an episode preview. Apply Draft, review, then Published enables Open in Google Photos for the exact item and Open album instead fallback. Move to Next episode and click again. No automatic cycling. Refresh extension after replacing its files with an updated ZIP. Shared URL works only while Google permits access; no permanent-link guarantee.
